package Aplicacion;

public class Principal {

	public static void main(String[] args) {
		Ventana miventana = new Ventana();
		miventana.setVisible(true);

		Ventana1 miventana1 = new Ventana1();
		miventana1.setVisible(true);

		Ventana2 miventana2 = new Ventana2();
		miventana2.setVisible(true);

		Ventana3 miventana3 = new Ventana3();
		miventana3.setVisible(true);

		Ventana4 miventana4 = new Ventana4();
		miventana4.setVisible(true);

		Ventana5 miventana5 = new Ventana5();
		miventana5.setVisible(true);

		Ventana6 miventana6 = new Ventana6();
		miventana6.setVisible(true);

		Ventana7 miventana7 = new Ventana7();
		miventana7.setVisible(true);

		Ventana8 miventana8 = new Ventana8();
		miventana8.setVisible(true);

	}

}