module CAMILA {
	requires java.desktop;
}